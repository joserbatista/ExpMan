/* global angular */
(function () {
    'use strict';

    /**
     * @ngdoc function
     * @name app.module:AccountModule
     * @description
     * # accountModule
     * Module of the app
     */

    angular.module('account', []);
})();
